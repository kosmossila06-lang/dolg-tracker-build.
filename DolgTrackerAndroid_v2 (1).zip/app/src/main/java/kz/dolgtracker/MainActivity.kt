package kz.dolgtracker

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import android.text.InputType

class MainActivity : Activity() {
    private val bg = Color.rgb(9, 11, 10)
    private val card = Color.rgb(17, 21, 18)
    private val green = Color.rgb(57, 232, 121)
    private val white = Color.WHITE
    private val muted = Color.rgb(168, 180, 170)
    private lateinit var root: LinearLayout
    private lateinit var summary: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var progressText: TextView
    private lateinit var daysText: TextView
    private lateinit var debtList: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DebtStore.ensureInitialized(this)
        buildUi()
        render()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(bg)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(28))
        }
        scroll.addView(root)
        setContentView(scroll)

        root.addView(text("ДОЛГ: ТРЕКЕР", 13, green, true))
        root.addView(text("Твой путь к нулю", 25, white, true).apply {
            setPadding(0, dp(6), 0, dp(16))
        })

        val summaryCard = panel()
        summary = text("", 28, white, true)
        summaryCard.addView(text("ОСТАЛОСЬ ПОГАСИТЬ", 11, muted, true))
        summaryCard.addView(summary)
        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progressTintList = android.content.res.ColorStateList.valueOf(green)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(40, 53, 44))
        }
        summaryCard.addView(progressBar, LinearLayout.LayoutParams(-1, dp(9)).apply {
            topMargin = dp(12)
        })
        progressText = text("", 13, green, true)
        summaryCard.addView(progressText)
        daysText = text("", 12, muted, false)
        summaryCard.addView(daysText)
        root.addView(summaryCard)

        root.addView(text("МОИ ДОЛГИ", 12, muted, true).apply {
            setPadding(0, dp(22), 0, dp(8))
        })
        debtList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(debtList)

        val payButton = Button(this).apply {
            text = "＋  Отметить платёж"
            setTextColor(Color.BLACK)
            backgroundTintList = android.content.res.ColorStateList.valueOf(green)
            setOnClickListener { showPaymentDialog() }
        }
        root.addView(payButton, LinearLayout.LayoutParams(-1, dp(52)).apply {
            topMargin = dp(18)
        })

        val reset = TextView(this).apply {
            text = "Сбросить прогресс"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(muted)
            setPadding(0, dp(18), 0, dp(8))
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("Сбросить прогресс?")
                    .setMessage("Все остатки вернутся к первоначальным суммам.")
                    .setNegativeButton("Отмена", null)
                    .setPositiveButton("Сбросить") { _, _ ->
                        DebtStore.reset(this@MainActivity)
                        render()
                    }.show()
            }
        }
        root.addView(reset)
    }

    private fun render() {
        val remaining = DebtStore.totalRemaining(this)
        val progress = DebtStore.progress(this)
        summary.text = DebtStore.money(remaining)
        progressBar.progress = progress
        progressText.text = "Погашено ${DebtStore.money(DebtStore.totalPaid(this))} • $progress%"
        daysText.text = "До конца 90-дневной цели: ${DebtStore.daysLeft(this)} дн."
        debtList.removeAllViews()
        DebtStore.debts(this).forEachIndexed { index, debt ->
            val row = panel()
            val line = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            labels.addView(text(debt.name, 16, white, true))
            labels.addView(text("Старт: ${DebtStore.money(debt.initial)}", 11, muted, false))
            line.addView(labels, LinearLayout.LayoutParams(0, -2, 1f))
            val right = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.END
            }
            right.addView(text(DebtStore.money(debt.current), 15, if (debt.current == 0L) green else white, true))
            val button = TextView(this).apply {
                text = if (debt.current == 0L) "ЗАКРЫТО ✓" else "ВНЕСТИ ПЛАТЁЖ"
                textSize = 10f
                setTypeface(null, Typeface.BOLD)
                setTextColor(green)
                setPadding(dp(4), dp(6), 0, 0)
                setOnClickListener { showPaymentDialog(index) }
            }
            right.addView(button)
            line.addView(right)
            row.addView(line)
            debtList.addView(row)
        }
        DebtWidgetProvider.refresh(this)
    }

    private fun showPaymentDialog(preselected: Int = 0) {
        val debts = DebtStore.debts(this)
        val available = debts.indices.filter { debts[it].current > 0L }
        if (available.isEmpty()) {
            AlertDialog.Builder(this).setMessage("Все долги закрыты! Красавчик 💚")
                .setPositiveButton("Отлично", null).show()
            return
        }
        val names = available.map { debts[it].name }.toTypedArray()
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        val selected = available.indexOf(preselected).takeIf { it >= 0 } ?: 0
        spinner.setSelection(selected)
        val amount = EditText(this).apply {
            hint = "Сумма платежа в ₸"
            inputType = InputType.TYPE_CLASS_NUMBER
            setTextColor(white)
            setHintTextColor(muted)
        }
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(4))
            addView(spinner)
            addView(amount, LinearLayout.LayoutParams(-1, dp(52)))
        }
        AlertDialog.Builder(this)
            .setTitle("Отметить платёж")
            .setView(layout)
            .setNegativeButton("Отмена", null)
            .setPositiveButton("Сохранить", null)
            .create().also { dialog ->
                dialog.setOnShowListener {
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                        val value = amount.text.toString().trim().toLongOrNull()
                        if (value == null || value <= 0) {
                            amount.error = "Введи сумму больше нуля"
                            return@setOnClickListener
                        }
                        val debtIndex = available[spinner.selectedItemPosition]
                        DebtStore.addPayment(this, debtIndex, value)
                        dialog.dismiss()
                        render()
                    }
                }
                dialog.show()
            }
    }

    private fun panel(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(13), dp(14), dp(13))
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(card)
            cornerRadius = dp(16).toFloat()
            setStroke(dp(1), Color.rgb(40, 53, 44))
        }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) }
    }

    private fun text(value: String, size: Int, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            text = value
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
            setPadding(0, dp(2), 0, dp(2))
        }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
