package kz.dolgtracker

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class DebtWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        updateAll(context, manager, ids)
    }

    companion object {
        fun refresh(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val component = ComponentName(context, DebtWidgetProvider::class.java)
            val ids = manager.getAppWidgetIds(component)
            updateAll(context, manager, ids)
        }

        private fun updateAll(context: Context, manager: AppWidgetManager, ids: IntArray) {
            DebtStore.ensureInitialized(context)
            val remaining = DebtStore.totalRemaining(context)
            val progress = DebtStore.progress(context)
            ids.forEach { id ->
                val views = RemoteViews(context.packageName, R.layout.debt_widget)
                views.setTextViewText(R.id.widgetRemaining, DebtStore.money(remaining))
                views.setProgressBar(R.id.widgetProgress, 100, progress, false)
                views.setTextViewText(R.id.widgetProgressText, "Погашено: $progress%")
                val intent = Intent(context, MainActivity::class.java)
                val pending = PendingIntent.getActivity(
                    context, 0, intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.widgetRoot, pending)
                views.setOnClickPendingIntent(R.id.widgetOpen, pending)
                manager.updateAppWidget(id, views)
            }
        }
    }
}
