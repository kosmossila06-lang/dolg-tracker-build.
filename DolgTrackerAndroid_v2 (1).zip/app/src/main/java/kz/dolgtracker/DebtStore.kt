package kz.dolgtracker

import android.content.Context
import java.text.NumberFormat
import java.util.Locale

data class Debt(val name: String, val initial: Long, val current: Long)

object DebtStore {
    private const val PREFS = "debt_tracker"
    private const val START_KEY = "start_date"
    private val initialDebts = listOf(
        "Алиху" to 125000L,
        "Kaspi Red" to 75000L,
        "Рассрочка Kaspi" to 146497L,
        "Мама" to 40000L,
        "Б. Тане" to 9000L,
        "Микрозайм" to 44070L
    )

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun ensureInitialized(context: Context) {
        val p = prefs(context)
        val editor = p.edit()
        var changed = false
        initialDebts.forEachIndexed { index, pair ->
            val key = "balance_$index"
            if (!p.contains(key)) {
                editor.putLong(key, pair.second)
                changed = true
            }
        }
        if (!p.contains(START_KEY)) {
            editor.putLong(START_KEY, System.currentTimeMillis())
            changed = true
        }
        if (changed) editor.apply()
    }

    fun debts(context: Context): List<Debt> {
        ensureInitialized(context)
        val p = prefs(context)
        return initialDebts.mapIndexed { index, pair ->
            Debt(pair.first, pair.second, p.getLong("balance_$index", pair.second))
        }
    }

    fun totalInitial(): Long = initialDebts.sumOf { it.second }
    fun totalRemaining(context: Context): Long = debts(context).sumOf { it.current }
    fun totalPaid(context: Context): Long = totalInitial() - totalRemaining(context)
    fun progress(context: Context): Int =
        ((totalPaid(context).toDouble() / totalInitial()) * 100).toInt().coerceIn(0, 100)

    fun addPayment(context: Context, index: Int, amount: Long): Boolean {
        if (amount <= 0 || index !in initialDebts.indices) return false
        val p = prefs(context)
        val current = p.getLong("balance_$index", initialDebts[index].second)
        if (current <= 0L) return false
        val paid = amount.coerceAtMost(current)
        p.edit().putLong("balance_$index", current - paid).apply()
        return true
    }

    fun reset(context: Context) {
        val p = prefs(context)
        val e = p.edit()
        initialDebts.forEachIndexed { index, pair -> e.putLong("balance_$index", pair.second) }
        e.putLong(START_KEY, System.currentTimeMillis())
        e.apply()
    }

    fun daysLeft(context: Context): Int {
        val start = prefs(context).getLong(START_KEY, System.currentTimeMillis())
        val elapsed = ((System.currentTimeMillis() - start) / 86_400_000L).toInt()
        return (90 - elapsed).coerceAtLeast(0)
    }

    fun money(value: Long): String =
        NumberFormat.getIntegerInstance(Locale("ru", "RU")).format(value) + " ₸"
}
